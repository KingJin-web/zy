# caiyun

 中国移动云盘 AstrBot 插件系统实现，可以通过 Bot 管理移动云盘账号，包括登录、查看CK、删除CK、数据迁移、商品查询、商品更新、检测、一键检测、抢兑、立即兑换、查询、管理等功能。

## 已实现功能

- `云盘登录`：短信登录 / CK 登录
- `查看我的CK`
- `删除CK 序号`
- `数据迁移`
- `云盘商品`
- `云盘商品更新`
- `云盘检测`
- `云盘一键检测`
- `云盘抢兑`
- `立即兑换`
- `云盘查询`
- `云盘管理`

## 设计说明

- 所有网络请求使用 `httpx.AsyncClient`
- 短信轮询、批量检测、跨账号查询使用 `asyncio`，避免 `time.Sleep` 这类阻塞式写法
- 插件运行数据与源码分离，运行数据保存在：


- 插件源码保存在：


## 数据存储

AstrBot 版本用 JSON 文件存储移动云盘账号相关数据：

- `XH_yp_user.json`
- `XH_yp_token.json`
- `XH_yp_phone.json`
- `XH_yp_products.json`
- `XH_yp_exchange.json`
- `XH_yp_sessions.json`

## 关于“数据迁移”

AstrBot 插件从导出的 JSON 文件迁移数据至其它文件，作者用来更换数据名使用
正常情况下无用

请把旧数据导出后放到：


支持两种格式：

1. 单桶：`<前缀>.json`
2. 三桶：`<前缀>_user.json`、`<前缀>_token.json`、`<前缀>_phone.json`

## 配置

至少建议配置：

- `qinglong_url`
- `qinglong_client_id`
- `qinglong_client_secret`
- `qinglong_env_name`

如果不配置青龙，登录成功后的“同步到青龙”步骤会报出警告，但本地 CK 仍然会保存。

## 注意

- `云盘一键检测` 默认支持后台执行；如果配置了 `admin_user_ids`，则只有这些用户可以执行。
- 主动通知失效 CK 时，插件会使用最近一次记录到的 `unified_msg_origin` 回发消息；如果某个用户从未和机器人交互过，可能无法主动通知到该用户。
